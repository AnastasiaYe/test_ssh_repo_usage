def test_power(i: int) -> int:
    return i * i

